# grimo利用方法
## 引用
- `core` = [./grimo/core.py]
- `package` = [./grimo/package.py]
- `storage` = [./grimo/storage.py]
- `utils` = [./grimo/utils.py]

## TODO
1. `core`, `package`, `storage`, `utils` を表形式にして、
    大カテゴリ、関数、使い方、効果 で列にして欲しい。


## 出力言語
- markdown
- 1枚のファイル


