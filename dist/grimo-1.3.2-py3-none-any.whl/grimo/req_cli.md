# grimo利用方法
## 引用
- `core` = [./core.py]
- `package` = [./package.py]
- `storage` = [./storage.py]
- `utils` = [./utils.py]

## TODO
1. `core`, `package`, `storage`, `utils` に関して、cliで実行するためのファイルを作成して欲しい


## 出力
- cli.py
- 1枚のファイル

