# バナー自動生成要件定義書
## 引用
- `i18niwatoko` = [i18niwatoko]
- `cli` = [./clipy]
- `ja` = [./i18n/message.ja.yml]

## TODO
### `i18niwatoko`と`cli`を使って多言語でi18を作る。
